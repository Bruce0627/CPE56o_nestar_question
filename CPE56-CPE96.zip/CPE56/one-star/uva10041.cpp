// UVa 10041 - Vito's Family
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    int t;cin>>t;
    while(t--) {
        int n;cin>>n;
        vector<int> a(n);
        for(int &x:a) cin>>x;
        sort(a.begin(),a.end());
        long long distance=0;
        for(int x:a) distance+=abs(x-a[n/2]);
        cout << distance << '\n';
    }
}
