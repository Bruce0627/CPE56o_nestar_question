// UVa 10678 - The Grazing Cow
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    int t; cin>>t;
    while (t--) {
        double distance,length; cin>>distance>>length;
        cout << fixed << setprecision(3) << acos(-1.0)*length*sqrt(length*length-distance*distance)/4 << '\n';
    }
}
