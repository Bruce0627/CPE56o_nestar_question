// UVa 10473 - Simple Base Conversion
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    for (string value; cin >> value && value.front()!='-';) {
        if (value.size()>1 && tolower(value[1])=='x') cout << dec << stoull(value,nullptr,16) << '\n';
        else cout << "0x" << uppercase << hex << stoull(value) << '\n';
    }
}
