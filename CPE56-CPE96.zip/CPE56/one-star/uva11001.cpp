// UVa 11001 - Necklace
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    for (long long v,loss; cin>>v>>loss && (v||loss);) {
        long long best=0, answer=0;
        for (long long k=1; k*loss<v; ++k) {
            long long score=k*(v-k*loss);
            if (score>best) { best=score; answer=k; }
            else if (score==best) answer=0;
        }
        cout << answer << '\n';
    }
}
