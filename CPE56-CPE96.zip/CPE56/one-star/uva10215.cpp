// UVa 10215 - The Largest/Smallest Box
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    for (double a,b; cin >> a >> b;) {
        double cut = (a+b-sqrt(a*a-a*b+b*b))/6;
        cout << fixed << setprecision(3) << cut << ' ' << 0.0 << ' ' << min(a,b)/2 << '\n';
    }
}
