// UVa 10573 - Geometry Paradox
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    const double pi=acos(-1.0);
    int t; cin>>t;
    string line; getline(cin,line);
    while (t-- && getline(cin,line)) {
        istringstream input(line);
        double a,b; input>>a;
        cout << fixed << setprecision(4) << (input>>b ? 2*pi*a*b : pi*a*a/8) << '\n';
    }
}
