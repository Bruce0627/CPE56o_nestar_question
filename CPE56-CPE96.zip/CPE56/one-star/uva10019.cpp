// UVa 10019 - Funny Encryption Method
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    int t;cin>>t;
    while(t--) {
        string n;cin>>n;
        cout << bitset<64>(stoull(n)).count() << ' '
             << bitset<64>(stoull(n,nullptr,16)).count() << '\n';
    }
}
