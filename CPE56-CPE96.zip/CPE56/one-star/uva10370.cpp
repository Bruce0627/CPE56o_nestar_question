// UVa 10370 - Above Average
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    int t; cin >> t;
    while (t--) {
        int n; cin >> n;
        vector<int> marks(n);
        for (int &mark : marks) cin >> mark;
        int total=accumulate(marks.begin(),marks.end(),0);
        int above=count_if(marks.begin(),marks.end(),[&](int mark){return mark*n>total;});
        cout << fixed << setprecision(3) << 100.0*above/n << "%\n";
    }
}
