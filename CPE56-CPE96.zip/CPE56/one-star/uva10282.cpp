// UVa 10282 - Babelfish
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    map<string,string> dictionary;
    for (string line; getline(cin,line) && !line.empty();) {
        istringstream input(line);
        string english, foreign; input >> english >> foreign;
        dictionary[foreign]=english;
    }
    for (string query; cin >> query;) {
        auto result=dictionary.find(query);
        cout << (result==dictionary.end() ? "eh" : result->second) << '\n';
    }
}
