// UVa 11172 - Relational Operators
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    int t; cin>>t;
    while (t--) { long long a,b; cin>>a>>b; cout << (a<b?'<':a>b?'>':'=') << '\n'; }
}
