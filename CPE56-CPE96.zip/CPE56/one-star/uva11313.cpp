// UVa 11313 - Gourmet Games
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    int t; cin>>t;
    while (t--) {
        int n,m; cin>>n>>m;
        if ((n-1)%(m-1)) cout << "cannot do this\n";
        else cout << (n-1)/(m-1) << '\n';
    }
}
