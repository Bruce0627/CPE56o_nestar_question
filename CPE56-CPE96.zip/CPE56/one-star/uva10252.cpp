// UVa 10252 - Common Permutation
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    string a,b;
    while(getline(cin,a) && getline(cin,b)) {
        array<int,26> x{},y{};
        for(char c:a) ++x[c-'a'];
        for(char c:b) ++y[c-'a'];
        for(int i=0;i<26;++i) cout << string(min(x[i],y[i]),char('a'+i));
        cout << '\n';
    }
}
