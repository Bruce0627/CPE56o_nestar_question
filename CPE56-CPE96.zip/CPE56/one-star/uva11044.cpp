// UVa 11044 - Searching for Nessy
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    int t; cin>>t;
    while (t--) { int n,m; cin>>n>>m; cout << (n/3)*(m/3) << '\n'; }
}
