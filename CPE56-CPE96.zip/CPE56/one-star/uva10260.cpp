// UVa 10260 - Soundex
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    const string code = "01230120022455012623010202";
    for (string word; cin >> word;) {
        char previous = '0';
        for (char c : word) {
            char digit = code[c-'A'];
            if (digit != '0' && digit != previous) cout << digit;
            previous = digit;
        }
        cout << '\n';
    }
}
