// UVa 11470 - Square Sums
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    int tc=0;
    for(int n;cin>>n && n;) {
        vector<long long> sums((n+1)/2);
        for(int r=0;r<n;++r)
            for(int c=0;c<n;++c) {
                long long value;cin>>value;
                sums[min({r,c,n-1-r,n-1-c})]+=value;
            }
        cout << "Case " << ++tc << ':';
        for(long long sum:sums) cout << ' ' << sum;
        cout << '\n';
    }
}
