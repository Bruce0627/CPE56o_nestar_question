// UVa 11461 - Square Numbers
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    for (int a,b; cin>>a>>b && (a||b);)
        cout << max(0,int(floor(sqrt(b))-ceil(sqrt(a))+1)) << '\n';
}
