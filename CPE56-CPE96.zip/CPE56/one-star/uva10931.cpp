// UVa 10931 - Parity
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    for (long long n;cin>>n && n;) {
        string digits;
        for (;n;n/=2) digits+=char('0'+n%2);
        reverse(digits.begin(),digits.end());
        cout << "The parity of " << digits << " is " << count(digits.begin(),digits.end(),'1') << " (mod 2).\n";
    }
}
