// UVa 11000 - Bee
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    for (int n; cin>>n && n>=0;) {
        uint64_t male=0,female=1;
        while (n--) {
            uint64_t nextMale=male+female;
            female=male+1;
            male=nextMale;
        }
        cout << male << ' ' << male+female << '\n';
    }
}
