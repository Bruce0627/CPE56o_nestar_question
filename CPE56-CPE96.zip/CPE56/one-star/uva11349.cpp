// UVa 11349 - Symmetric Matrix
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    int t;cin>>t;
    for(int tc=1;tc<=t;++tc) {
        char label,equalSign;
        int n;cin>>label>>equalSign>>n;
        vector<long long> matrix(n*n);
        bool symmetric=true;
        for(auto &value:matrix) { cin>>value; symmetric &= value>=0; }
        symmetric &= equal(matrix.begin(),matrix.end(),matrix.rbegin());
        cout << "Test #" << tc << ": " << (symmetric?"Symmetric.\n":"Non-symmetric.\n");
    }
}
