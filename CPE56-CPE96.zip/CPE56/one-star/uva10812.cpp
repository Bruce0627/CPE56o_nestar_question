// UVa 10812 - Beat the Spread!
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    int t;cin>>t;
    while(t--) {
        long long sum,difference;cin>>sum>>difference;
        if(difference>sum || (sum-difference)%2) cout << "impossible\n";
        else cout << (sum+difference)/2 << ' ' << (sum-difference)/2 << '\n';
    }
}
