// UVa 10474 - Where is the Marble?
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    int tc=0;
    for (int n,q; cin >> n >> q && (n||q);) {
        vector<int> a(n);
        for (int &x : a) cin >> x;
        sort(a.begin(),a.end());
        cout << "CASE# " << ++tc << ":\n";
        while (q--) {
            int x; cin >> x;
            auto it=lower_bound(a.begin(),a.end(),x);
            cout << x;
            if (it!=a.end() && *it==x) cout << " found at " << it-a.begin()+1 << '\n';
            else cout << " not found\n";
        }
    }
}
