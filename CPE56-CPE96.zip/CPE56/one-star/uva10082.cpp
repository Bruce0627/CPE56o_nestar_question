// UVa 10082 - WERTYU
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    string keys = string(1, char(96)) + "1234567890-=QWERTYUIOP[]\\ASDFGHJKL;'ZXCVBNM,./";
    for (char c; cin.get(c);) {
        size_t i = keys.find(c);
        cout << (i != string::npos && i > 0 ? keys[i-1] : c);
    }
}
