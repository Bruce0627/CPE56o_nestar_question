// UVa 10226 - Hardwood Species
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    int t;cin>>t;
    string line;getline(cin,line);
    getline(cin,line);
    while(t--) {
        map<string,int> counts;
        int total=0;
        while(getline(cin,line) && !line.empty()) { ++counts[line]; ++total; }
        for(const auto &[name,count]:counts)
            cout << name << ' ' << fixed << setprecision(4) << 100.0*count/total << '\n';
        if(t) cout << '\n';
    }
}
