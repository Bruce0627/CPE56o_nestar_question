// UVa 10222 - Decode the Mad Man
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    const string keys=string(1,char(96))+"1234567890-=qwertyuiop[]\\asdfghjkl;'zxcvbnm,./";
    for(char c;cin.get(c);) {
        size_t index=keys.find(tolower(static_cast<unsigned char>(c)));
        cout << (index!=string::npos && index>=2 ? keys[index-2] : c);
    }
}
