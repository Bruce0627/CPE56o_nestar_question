// UVa 10310 - Dog and Gopher
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    int n; double gx,gy,dx,dy;
    while (cin >> n >> gx >> gy >> dx >> dy) {
        bool escaped=false;
        for (int i=0; i<n; ++i) {
            double x,y; cin >> x >> y;
            double g=(x-gx)*(x-gx)+(y-gy)*(y-gy), d=(x-dx)*(x-dx)+(y-dy)*(y-dy);
            if (!escaped && d>=4*g) {
                cout << fixed << setprecision(3) << "The gopher can escape through the hole at (" << x << ',' << y << ").\n";
                escaped=true;
            }
        }
        if (!escaped) cout << "The gopher cannot escape.\n";
    }
}
