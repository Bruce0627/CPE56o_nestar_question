// UVa 490 - Rotating Sentences
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    vector<string> lines;
    size_t width=0;
    for(string line;getline(cin,line);) {
        width=max(width,line.size());
        lines.push_back(line);
    }
    for(size_t c=0;c<width;++c) {
        for(auto row=lines.rbegin();row!=lines.rend();++row) cout << (c<row->size()?(*row)[c]:' ');
        cout << '\n';
    }
}
