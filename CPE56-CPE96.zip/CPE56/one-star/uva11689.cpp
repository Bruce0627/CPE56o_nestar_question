// UVa 11689 - Soda Surpler
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    int t;cin>>t;
    while(t--) {
        int e,f,c;cin>>e>>f>>c;
        int bottles=e+f, drank=0;
        while(bottles>=c) {
            int exchanged=bottles/c;
            drank+=exchanged;
            bottles=exchanged+bottles%c;
        }
        cout << drank << '\n';
    }
}
