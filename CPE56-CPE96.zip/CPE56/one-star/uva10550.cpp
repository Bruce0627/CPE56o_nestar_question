// UVa 10550 - Combination Lock
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    for (int a,b,c,d; cin>>a>>b>>c>>d && (a||b||c||d);)
        cout << 1080+9*((a-b+40)%40+(c-b+40)%40+(c-d+40)%40) << '\n';
}
