// UVa 11764 - Jumping Mario
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    int t;cin>>t;
    for(int tc=1;tc<=t;++tc) {
        int n,previous,high=0,low=0;cin>>n>>previous;
        for(int i=1;i<n;++i) {
            int current;cin>>current;
            high+=current>previous; low+=current<previous;
            previous=current;
        }
        cout << "Case " << tc << ": " << high << ' ' << low << '\n';
    }
}
