// UVa 11059 - Maximum Product
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    int tc=0;
    for (int n; cin>>n;) {
        vector<long long> a(n);
        for (auto &x : a) cin>>x;
        long long best=0;
        for (int i=0; i<n; ++i) {
            long long product=1;
            for (int j=i; j<n; ++j) { product*=a[j]; best=max(best,product); }
        }
        cout << "Case #" << ++tc << ": The maximum product is " << best << ".\n\n";
    }
}
