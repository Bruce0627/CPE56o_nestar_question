// UVa 10420 - List of Conquests
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    int n;cin>>n;
    map<string,int> counts;
    while(n--) {
        string country,rest;cin>>country;
        getline(cin,rest);
        ++counts[country];
    }
    for(const auto &[country,count]:counts) cout << country << ' ' << count << '\n';
}
