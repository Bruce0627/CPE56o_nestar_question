// UVa 10190 - Divide, But Not Quite Conquer!
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    long long n,m;
    while (cin>>n>>m) {
        vector<long long> sequence={n};
        if (n>1 && m>1) {
            while (n>1 && n%m==0) { n/=m; sequence.push_back(n); }
        }
        if (n!=1 || sequence.size()<2) { cout << "Boring!\n"; continue; }
        for (size_t i=0;i<sequence.size();++i) cout << (i?" ":"") << sequence[i];
        cout << '\n';
    }
}
