// UVa 11417 - GCD
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    array<long long,501> total{};
    for(int n=2;n<=500;++n) {
        total[n]=total[n-1];
        for(int i=1;i<n;++i) total[n]+=gcd(i,n);
    }
    for(int n;cin>>n && n;) cout << total[n] << '\n';
}
