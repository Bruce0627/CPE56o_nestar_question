// UVa 10268 - 498’
#include <algorithm>
#include <array>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

using namespace std;

int main() {
    long long x;string line;
    while(cin>>x) {
        getline(cin,line);
        getline(cin,line);
        istringstream input(line);
        vector<long long> a;
        for(long long coefficient;input>>coefficient;) a.push_back(coefficient);
        long long result=0;
        for(size_t i=0;i+1<a.size();++i)
            result=result*x+a[i]*static_cast<long long>(a.size()-1-i);
        cout << result << '\n';
    }
}
